#error "Run configure.bat to create platform.h"
